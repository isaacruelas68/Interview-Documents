import random
import time
import numpy as np
import matplotlib.pyplot as plt
import statistics


# Stable_Count_Sort Algorithm
def Stable_Count_Sort(A, n, option,
                      logCount):  # (Array, size of array, option decides whether or not there is an empirical
    # print of the count process,keeps record of times )
    begin = time.time()
    k = n + 1
    C = []
    B = []

    [C.append(0) for i in range(0, k)]  # fills C array with 0s 0-10

    for j in range(0, n):  # this loop counts the amount of times a number is repeated
        C[A[j]] = C[A[j]] + 1

    for i in range(1, k):  # this loop adds the previous index with the current one
        C[i] = C[i] + C[i - 1]

    [B.append(0) for run in range(0, C[len(C) - 1])]  # create an array of the size of the last num in C so if
    # C=size10 C[9] holds the biggest number

    for j in range(n - 1, -1, -1):
        if option == 0:
            print("A[", j, "] = ", A[j])
            print("C[", A[j], "] = ", C[A[j]])
            print("B[", C[A[j]] - 1, "] = ", A[j])
        B[C[A[j]] - 1] = A[j]
        if option == 0:
            print("C[", A[j], "]= ", C[A[j]] - 1)
        C[A[j]] = C[A[j]] - 1
        if option == 0:
            print("This Array A: ", A)
            print("This Array B: ", B)
            print("This Array C: ", C)
            print()
    end = time.time()
    finalTime = end - begin
    logCount.append(finalTime)
    print("Stable Count Sort took: ", finalTime, " seconds!")
    return B


###########################################################################################################
# HEAP_SORT ALGORITHM
def Heapify(A, i, n, skip):
    if skip == 0:
        print("n = ", n, "i = ", i)
        print("The array is: ", A)
    if ((2 * i) <= n) and (A[2 * i] > A[i]):  # left child

        largest = 2 * i
    else:
        largest = i

    if (((2 * i) + 1) <= n) and (A[(2 * i) + 1] > A[largest]):  # right child
        largest = ((2 * i) + 1)

    if largest != i:
        A[i], A[largest] = A[largest], A[i]
        Heapify(A, largest, n, skip)


def fill_arr(num_arr, size):
    for i in range(1, size + 1):
        num_arr[i] = random.randint(1, 100000)
    return


def Build_Heap(A, n, skip):
    if skip == 0:
        print("n =", n)
        print("The array Before its built is: ", A)
    initial = (int)(len(A) / 2)
    for start in range(initial, 0, -1):  # this for loop is incharge of building the heap
        Heapify(A, start, n, skip)


def Heap_Sort(A, n, skip, logHeap):
    start_time = time.time()
    Build_Heap(A, n, skip)
    if skip == 0:
        print("The Built Heap Array is: ", A)
    i = n
    for run in range(i, 1, -1):
        A[1], A[i] = A[i], A[1]
        i = i - 1
        Heapify(A, 1, i, skip)
    end_time = time.time()
    final = end_time - start_time
    logHeap.append(final)
    print("HeapSort time: ", final, " seconds")


#########################################################################
#  QUICK_SORT Algorithm

def Partition(B, p, r):  # the send parameter is only for printing purposes
    x = B[r]
    i = (p - 1)
    j = p
    for run in range(j, r):
        if B[j] <= x:
            i = i + 1
            B[i], B[j] = B[j], B[i]
        j = j + 1
    B[i + 1], B[r] = B[r], B[i + 1]
    return i + 1


def QuickSort(B, p, r, send):  # (array,pivot,total size,print empirical process )
    if p < r:
        if send == 0:
            print("p= ", p, "r = ", r, " Array before partition: ", B)
        q = Partition(B, p, r)
        if send == 0:
            print("p= ", p, "r = ", r, "Array after partition: ", B)
        QuickSort(B, p, q - 1, send)
        QuickSort(B, q + 1, r, send)


########################################### THIS IS THE MAIN ###########################################################
size = input("Please enter the size of array for count Sort you wish to have (please keep less than 100): ")
arr = [random.randint(1, int(size)) for run in range(0, int(size))]
print(arr)
before = arr
countLog = []
arr = Stable_Count_Sort(arr, len(arr), 0, countLog)
print()
print()
print('Unsorted Array: ', before)
print("Sorted Array: ", arr)

# size and time loggers
sizeLog = []
countLog = []
heapLog = []
quickLog = []

for run in range(0,8):  # this loop calls count sort and prints out the time of arrays increasing by 2^(0-7) powers
    # ranging from 10,000->1,280,000
    increase = (2 ** run) * 10000
    sizeLog.append(increase)  # save sizes in array

    # Stable Count Sort
    print("Arrays with ", (2 ** run) * 10000, " Elements: ")
    samples = [random.randint(1, increase) for run in range(0, increase)]  # this for loop fills the array with
    # rand nums based on 'increase'
    samples = Stable_Count_Sort(samples, len(samples), 1, countLog)

    # HeapSort
    numsH1 = [random.randint(1, 100000) for sprint in range(1, increase + 1)]
    Heap_Sort(numsH1, len(numsH1) - 1, 1, heapLog)

    # QuickSort
    numsQ1 = [random.randint(1, 100000) for walk in range(1, increase + 1)]
    start_time = time.time()
    QuickSort(numsQ1, 1, len(numsQ1) - 1, 1)
    end_Time = time.time()
    total = float(end_Time - start_time)
    quickLog.append(total)
    print("QuickSort time: ", total, " seconds")
    print()

print('Total sizes: ', sizeLog)
print('Total collective of times for Quick Sort: ', quickLog)
print('Total collective of times for Heap Sort: ', heapLog)
print('Total collective of times for Count Sort: ', countLog)
print()

print('Quick Sort mean: ', statistics.mean(quickLog))
print('Heap Sort mean: ', statistics.mean(heapLog))
print('Count Sort mean: ', statistics.mean(countLog))

#plotting code
plt.style.use('seaborn')
plt.plot(heapLog, sizeLog, 'ro-', linewidth=3, label=' heap sort O(n^2)')
plt.plot(quickLog, sizeLog,'bo-', linewidth=3, label='quick Sort O(n^2) ')
plt.plot(countLog, sizeLog, 'go-', linewidth=3, label='count sort O(nlgn)')
plt.ylabel('Size of Array')
plt.xlabel('Time (s)')
plt.title("Time vs Size")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()
#########################################################################################################
