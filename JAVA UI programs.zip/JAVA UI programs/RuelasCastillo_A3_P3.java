/*
 ISAAC RUELAS CASTILLO ASSIGNMENT 3 PROBLEM 3
 */
package ruelascastillo_a3_p3;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import static java.lang.Math.abs;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.layout.VBox;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.geometry.Insets;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;

/**
 *
 * @author Isaac's PC
 */
public class RuelasCastillo_A3_P3 extends Application {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {
        //panels
        BorderPane pane = new BorderPane();//exterior pane
        VBox leftVBox = new VBox();
        leftVBox.setMaxHeight(200);
       
        VBox cvB = new VBox();
        ScrollPane scroll = new ScrollPane();
        cvB.scaleYProperty();
        

        //layout
        pane.setLeft(leftVBox);
        pane.setCenter(scroll);  
        scroll.setContent(cvB);
       
        //padding
        pane.setPadding(new Insets(20, 20, 20, 20));
        scroll.setPadding(new Insets(50, 50, 50, 50));
      
      
        //Button
        Button load=new Button("load");
        
        //set OnAction code
        load.setOnAction((ActionEvent e) -> {
       cvB.getChildren().clear();
      
       
            //file chooser
        FileChooser fileChooser = new FileChooser();
        File selectedFile = fileChooser.showOpenDialog(stage);
       fileChooser.getExtensionFilters().add(new ExtensionFilter( "Excel","*.csv"));
        
        String fs;
 int counter=0;
       BufferedReader read;
            try {
                read = new BufferedReader(new FileReader(selectedFile.getAbsolutePath())); //read the files
                   
     //variables
      int dem,demCounter=0,repCounter=0,wasteDem=0,wasteRep=0,total,win;
      int rep;
      double repCent,demCent;
      double finalDem,finalRep;
      String holdRep;
      String distName;
      String holdDem;
      //the arrays for all our FX
      HBox box[]=new HBox[40]; 
      Rectangle demRects[]=new Rectangle[40];
      Rectangle repRects[]=new Rectangle[40];
      Label label[]=new Label[40];
      Label demScore,repScore,gerryScore;
     
            demScore=new Label(" ");
            repScore=new Label(" ");
            gerryScore=new Label(" ");
                while ((fs = read.readLine()) != null)
                {
                    box[counter]= new HBox();
                    box[counter].setPadding(new Insets(2,2,2,2));
                    demRects[counter]=new Rectangle();
                    repRects[counter]=new Rectangle();
                    label[counter]=new Label();
                    
                 //these grap the int and name 
                    distName=fs.substring(6, fs.lastIndexOf(" "));// grabs the name
                    holdDem=fs.substring(fs.lastIndexOf(" ,")+2, fs.lastIndexOf(","));//grabs the democratic number
                    holdRep=fs.substring(fs.lastIndexOf(",")+1,fs.lastIndexOf(""));//rep
                    
                    //these turn to int and define the label
                    label[counter]=new Label(distName);//new labels
                    dem=Integer.parseInt(holdDem);//turns string into int
                    rep= Integer.parseInt(holdRep);
                    
                    //calculation for total vote
                    demCounter=demCounter+dem;
                    repCounter=repCounter+rep;
                    total=dem+rep;
                    win=(total/2)+1;
                    if(dem>win)
                    {wasteDem=abs(dem-win)+wasteDem;
                    wasteRep=rep+wasteRep;
                    }
                    if(rep>win)
                    {
                        wasteRep=abs(win-rep)+wasteRep;
                        wasteDem=dem+wasteDem;
                    }
                 
                    
                    //cuts the nmbers to percents
                   repCent=((double)rep/(double)total);
                   demCent=((double)dem/(double)total);
                    //RECTANGLES
                    repRects[counter] = new Rectangle(((repCent)*350), 20, Color.RED);
                    demRects[counter]=new Rectangle((demCent*350),20,Color.BLUE);
                    
                    //adds the rectangles to the Hbox then to center box
                    box[counter].getChildren().addAll(repRects[counter],demRects[counter],label[counter]);
                    cvB.getChildren().add(counter, box[counter]);
                    
                    counter++;
             }
                read.close();
                //this code grabs the final percent
            finalDem=(double)wasteDem/(double)demCounter;
            finalRep=(double)wasteRep/(double)repCounter;
            
            //prints out the final score
            demScore.setText("Wasted Democratic Votes"+wasteDem+" "+finalDem+"%");
            repScore.setText("Wasted Republican Votes"+wasteRep+" "+finalRep+"%");
            leftVBox.getChildren().add(1,demScore);
            leftVBox.getChildren().add(2, repScore);
            
           //determination for gerrymandering
            if(((finalDem-finalRep)>7)&&(finalDem<finalRep))
            gerryScore.setText("Democratic party Gerrymandered");
            if(((finalDem-finalRep)>7)&&(finalDem>finalRep))
            gerryScore.setText("Republican party Gerrymandered");
            if((finalDem -finalRep)<7)
                gerryScore.setText("Not Gerrymandered");
            
            leftVBox.getChildren().add(3,gerryScore);
            
            } catch (IOException ex) { }
            
        
        });
        
        

        
        
      
       

      
        //Labels
        Label label1;

        label1 = new Label("Alaska Gerrymandering Results");
      

  

        
        leftVBox.getChildren().add(load);

       

        

        
        Scene scene = new Scene(pane, 900, 600);
        stage.setTitle("Gerrymandering Analysis");
        stage.setScene(scene);
        stage.show();

    }

}
