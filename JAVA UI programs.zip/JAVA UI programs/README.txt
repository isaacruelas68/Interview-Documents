

Hello! Below Are Several programs that I have written in previous classes.

The two Java programs are focused on JAVA fx in which display UI's 

Programs:

RuelasCastillo_A3_P2- is a graphical user survey


RuelasCastillo_A3_P3- is a UI displaying data in rectangular charts and printing 
a statistical analysis of gerrymandering in Alaska (The two csv files are specific for
this program) 

Thank you 

-Isaac Ruelas Castillo