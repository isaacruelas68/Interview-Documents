/*
 ISAAC RUELAS CASTILLO ASSIGNMENT 3 PROBLEM 2
 */
package ruelascastillo_a3_p2;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.text.Font;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Spinner;
import javafx.event.ActionEvent;
import javafx.scene.control.ToggleGroup;
import javafx.scene.paint.Color;

/**
 *
 * @author Isaac's PC
 */
public class RuelasCastillo_A3_P2 extends Application {

    /**
     * @param stage
     * @throws Exception
     */
   

    @Override
    public void start(Stage stage) throws Exception
    {
        GridPane root= new GridPane();//sets the grid
        root.setVgap(5);
        root.setHgap(5);
       
        //labels created
        Label label1, label2,label3, label4;
        
        label1= new Label("Good evening! Please fill out the survey so we can know you better!");
        label1.setFont(Font.font("Times New Roman",24));
        
        label2=new Label("What is your favorite color?");
        label2.setFont(Font.font("Times New Roman",15));
        
        label3=new Label("What is your favorite programming language?");
        label3.setFont(Font.font("Times New Roman", 15));
      
        label4=new Label("What is your age?");
        label4.setFont(Font.font("Times New Roman",15));
        
        //Radio Button creation   
        ToggleGroup tg=new ToggleGroup();
        
        RadioButton color1=new RadioButton("Orange");;
        RadioButton color2=new RadioButton("Green");
        RadioButton color3=new RadioButton("Blue");
        RadioButton color4=new RadioButton("Red");
    //sets color of radio buttons
        color1.setTextFill(Color.ORANGE);
        color2.setTextFill(Color.GREEN);
         color3.setTextFill(Color.BLUE);
         color4.setTextFill(Color.RED);
        
    //they get placed in toggle group
    color1.setToggleGroup(tg);
    color1.setSelected(true);
    color2.setToggleGroup(tg);
    color3.setToggleGroup(tg);
    color4.setToggleGroup(tg);
    
    //added to the grid pane    
         root.add(color1, 0, 3);
        root.add(color2, 0, 4);
        root.add(color3, 0, 5);
        root.add(color4, 0, 6);
        
        
        //label alignment
                   //column,row
        root.add(label1,0,0);//title
        root.add(label2,0,2);//color qs
        root.add(label4,0,7);//age qs
        root.add(label3,0,9);//programming qs
       
        //spinner
        Spinner value;
        value= new Spinner(10,100,10);
        root.add(value, 0, 8);
        
        //choice box
      ChoiceBox<String> box=new ChoiceBox<>( 
      FXCollections.observableArrayList("C++", "Python", "C#","FORTRAN","russian C++","Ruby"));
      root.add(box,0,10);
      
       //Summary button
       Button summary =new Button("Submit");
       Label sum=new Label();
       Label age=new Label();
       Label lang=new Label();
       root.add(sum, 0, 12);
       root.add(age,0,13);
       root.add(lang,0,14);
       
 summary.setOnAction((ActionEvent e) -> {
   //labels to be printed based on selection
     if(color1.isSelected())
    sum.setText("FavoriteColor: "+color1.getText());
    if(color2.isSelected())
     sum.setText("FavoriteColor: "+color2.getText());
    if(color3.isSelected())
        sum.setText("FavoriteColor: "+color3.getText());
    if(color4.isSelected())
           sum.setText("FavoriteColor: "+color4.getText());
       
    age.setText("Your age is: "+value.getValue());
     lang.setText("Your favorite programming language is: " +  box.getValue());
        });
 
       root.add(summary,0,11);
 
       
       
 Scene scene = new Scene(root,700,400);
 stage.setTitle("Human Survey for Alien testing");
 stage.setScene(scene);
 stage.show();
    }
    
       public static void main(String[] args) {
      launch(args);
     
    }
}
